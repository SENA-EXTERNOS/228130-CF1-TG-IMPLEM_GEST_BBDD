function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5dxx84N5Mxe":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

